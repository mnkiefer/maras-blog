# Fieldnotes — Research & AI

A personal blog for research, AI, and curious thinking.

This is a lightweight, responsive **static website** inspired by Astro's clean editorial blog style. No dependencies or build tools are needed.

## Files

- `index.html` — homepage, About section, newsletter preview, and article layout
- `style.css` — styling and mobile responsive layout
- `script.js` — sample posts, filters and navigation
- `assets/hero.png` — custom hero illustration

## Publish with GitHub Pages

1. Upload the **contents** of this folder to the root of your repository. Keep the `assets` subfolder.
2. Go to **Settings → Pages** in the GitHub repository.
3. Under **Build and deployment**, select **Deploy from a branch**.
4. Choose your main branch and the root (`/`) folder, then save.

If the repository is private, GitHub Pages availability depends on your GitHub plan and settings.

## Customize

Article cards and sample articles are in `script.js`. Replace them with your own research and AI writing.

The newsletter is only a design preview. It does not collect email addresses until you connect a subscription service.
